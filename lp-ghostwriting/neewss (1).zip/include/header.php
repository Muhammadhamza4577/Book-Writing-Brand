<!-- Header Start -->
<header>
<div class="top-bar">
<div class="container">
<div class="tp-bar-blk">
<a class="hdr-email" href="mailto:info@bestbookwriters.com"><i class="fa fa-envelope" aria-hidden="true"></i>info@bestbookwriters.com</a>
<ul>
<li><a href="https://twitter.com/BestBookWriters" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a target="_blank" href="https://www.linkedin.com/company/best-book-writers/"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a target="_blank" href="https://www.facebook.com/BestBookWriters/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a target="_blank" href="https://www.instagram.com/bestbookwriters/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
</ul>
</div>
</div>
</div>
<div class="hdr-btm">
<div class="container">
<div class="hdr-blk">
<a class="brand-name" href="https://bestbookwriters.com/"><img src="images/logo.png" alt=""></a>
<div class="hdr-btn">
<button type="button" class="hvr-grow tc-image-effect-shine" data-bs-toggle="modal" data-bs-target="#exampleModal">Get Started<i class="fa fa-angle-right" aria-hidden="true"></i></button>
<a class="hdr-btn2" href="tel:+1-737-881-7227">+1-737-881-7227<i class="fa fa-angle-right" aria-hidden="true"></i></a>
</div>
</div>
</div>
</div>
</header>
<!-- Header End -->