<?php include 'include/head.php';?>
<?php include 'include/header.php';?>

<section class="banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="slide-cap text-center" style="margin:190px 0">
<h1>Thank You</h1>
<p class="text-white" style="color:#fff;z-index:999;position:relative">We appreciate you contacting us. One of our colleagues will get back in touch with you soon!Have a great day!.</p>
</div>
</div>
</div>
</div>
<div class="magzine-img"><img src="images/magzine.png" alt=""></div>
</section>




 <?php include 'include/footer.php';?>
<?php include 'include/links.php';?>



