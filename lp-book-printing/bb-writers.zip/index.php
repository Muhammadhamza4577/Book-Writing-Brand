<?php include 'include/head.php';?>

<?php include 'include/header.php';?>
    

<section class="banner">
	<div class="container-fluid">
		<div class="bannner-content">
			<h1>Stunning Editions<br>Made By You</h1>
		</div>
	</div>
</section>


<section class="beautiful-books">
	<div class="container">
		<div class="beautiful-books-header">
			<h1>Print Beautiful Books for Any Occasion</h1>
			<p>Create high quality paperback or hardcover books for your friends & family, your business, fans of your book, prospective readers & reviewers, and yourself. We’ll deliver copies to your door in about 10 days from the date you place your order. Some exceptions apply. Once your book is in our system, it’s easy to create different formats, make changes, or sell it on Best Book Writers</p>
		</div>
		<div class="row">
			
			<div class="col-md-6">
				<div class="beauty-book-content">
					<img src="images/image_hiqh_quality.jpg">
				</div>
			</div>

			<div class="col-md-6">
				<div class="beauty-book-content">
					<h3>Professional Quality & Easy<br>to Print</h3>
					<p>We use premium paper stock and print in full color or crisp black and white. Choose from stunning hardcover editions, including hardcover with dust jacket or hardcover with printed case, or versatile paperbacks. Whatever options you pick, creating and printing your book is as easy as 1, 2, 3.</p>
					<div class="choosing-options">
						<div class="row">
							<div class="col-md-4">
								<span>1</span>
								<p>Choose Your<br>Format</p>
							</div>
							<div class="col-md-4">
								<span>2</span>
								<p>Prepare & Upload<br>Your Files</p>
							</div>
							<div class="col-md-4">
								<span>3</span>
								<p>Print &<br>Ship</p>
							</div>
						</div>
						<a href="javascript:void(0)">Get Started</a>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>

<section class="book-print">
	<div class="container">
		<div class="book-print-header">
			<h3>Book Printing Costs</h3>
			<p>Use the tool below to determine exactly how much it will cost to print your book.</p>
		</div>
		<div class="book-print-form">
			<form>
				<div class="row">
					<div class="col-md-6">
						<input type="text" name="" placeholder="First Name">
						<input type="text" name="" placeholder="Last Name">
					</div>
					<div class="col-md-6">
						<input type="text" name="" placeholder="Phone Number">
						<input type="text" name="" placeholder="Company Name">
					</div>
				</div>
				<select>
							<option disabled selected>Estimated Page Count</option>
							<option>18-50</option>
							<option>51-100</option>
							<option>101-150</option>
							<option>151-200</option>
							<option>201-250</option>
							<option>251-300</option>
							<option>301-350</option>
							<option>351-400</option>
							<option>401-450</option>
							<option>451-500</option>
							<option>501-550</option>
							<option>551-600</option>
							<option>601-650</option>
							<option>651-700</option>
							<option>701-750</option>
							<option>751-800</option>
							<option>801-950</option>
						</select>
			</form>
		</div>
	</div>
</section>


<section class="share-your-story">
	<div class="container-fluid">
		<div class="share-your-story-header">
			<h3>Share Your Story</h3>
		</div>
		<div class="story-cta">
			<div class="container">
				<div class="row">
				<div class="col-md-6">
					<img src="images/share_your_story_banner_books.png">
				</div>
				<div class="col-md-6">
					<h4>Thinking about selling your book? Once your book is in our system, it’s easy to sell it on Best Book Writers<br><a href="javascript:void(0)">Learn More</a></h4>
				</div>
			</div>
			</div>
		</div>
	</div>
</section>


<section class="boxx">
	<div class="container">
		<div class="boxx-text">
			<p>Discover how to print your own book with Barnes & Noble Press. Book printing is easy and affordable! From beautiful hardcover books to affordable paperbacks, printing your own books is a great way to preserve treasured memories, share favorite stories, and lend a personal touch. Consider printing a cookbook filled with your family recipes, or a travel log of photographs, or even a memoir of your life story. You don’t need to be a professional writer, artist, or photographer to print your own book! Choosing to print on demand books can be a fun, original project for those who are looking to spend more time channeling their creative selves. If you’re a literature fanatic, consider writing a short story, book of poetry, or maybe the next great American Novel! You can have fun writing and printing a paperback or hardcover book for your own keepsake to see on your shelf. If you love to draw, a picture book can be a challenging, yet rewarding activity. Our book printing service creates professional, high-quality books for whatever you choose to do. Whether you have a 50-page book or 500-page book, Barnes & Noble Press is the expert partner you need for book printing. Trust the largest bookstore in America to help you bring your book to life! Whatever your passion, with Best Book Writers Press we make your dreams of printing your own book a reality.</p>
		</div>
	</div>
</section>



<?php include 'include/footer.php';?>
<?php include 'include/links.php';?>


