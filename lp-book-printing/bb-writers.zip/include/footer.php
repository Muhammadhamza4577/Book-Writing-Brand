<footer>
    <div class="container">
    	<div class="copy-right">
    		<img src="images/logo.png">
    		<p>All Rights Reserved 2023 - Best Book Writers</p>
    	</div>
    </div>
</footer>