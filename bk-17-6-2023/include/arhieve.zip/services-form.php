<form data-noinfo="true" data-customcallback="querycallback" class="CrudForm cmxform" id="signup-form" method="POST" action="include/sendmail">
                        <input type="hidden" required name="page_url" value="https://bestbookwriter.com" />  
          <div class="alert alert-danger error" style="display: none;"></div>
<div class="container">
<div class="row justify-content-center">
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<input type="text" placeholder="Enter your Name*" name="Name" required>
</div>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<input type="email" placeholder="Enter your Email*" name="Email" required>
</div>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<input type="number" id="phone" placeholder="Enter your Number*" name="phone" required class="form-control" />
</div>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<textarea name="Description" id="" cols="30" rows="10" placeholder="Type Description Here"></textarea>
</div>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
<button class="hvr-grow tc-image-effect-shine" type="submit">LET'S TALK</button>
</div>
</div>
</div>
</form> 