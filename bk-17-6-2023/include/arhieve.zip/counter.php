<section class=" our-satisfied-customer-stats our-satisfied-customer-stats1">
<div class="our-satisfied-customer-content">
<h3>We’ve Got the Numbers Rolling</h3>
<p>We are proud to have a track record of delivering exceptional client results. Our numbers speak for themselves, and we constantly strive to improve and exceed expectations.</p>
<div class="our-satisfied-counts numbers">
<div class="counter-container">
 	<h2 class="value">2517</h2>
<span>Total projects</span>
</div>
<div class="counter-container">
 	<h2 class="value">517</h2>
<span>Total projects completed</span>
</div>
<div class="counter-container">
 	<h2 class="value">800</h2>
<span>Happy clients</span>
</div>

<div class="counter-container">
  	<h2 class="value">800</h2>
<span>Satisfied clients</span>
</div>

</div>
</div>
</section>