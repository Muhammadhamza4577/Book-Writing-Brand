<section class="sec-testimonials">
<div class="container">
<div class="head">
<h6>What Our Clients Say Only Motivates Us to Go <br> Above &amp; Beyond Their Expectations. </h6>
</div>
 <div class="row justify-content-center">
     
<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc">
<h6>True Johnson</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Great coordination!</b>
<div class="overflow">
<p>I understand the fact that I am not the best writer in the world and that is the reason why looked out for different online editing services.
The quotes offered to me were too much, but I opted for Best Book Writers. My Warner was really helpful and he coordinated with me in
framing up different chapters. Thanks a lot Best Book Writers guys, you guys are good. </p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc">
<h6>Courtney Sam</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Top service and accurate delivery</b>
<div class="overflow">
<p>After completing my book I realized that how arduous book writing can be even for people who are good in writing. The technical details along 
with the formatting as a bit tough on my side. I contacted Best Book Writers editing services and these guys delivered my work after
various corrections in just 72 hours. </p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc2">
<h6>Simon Abbot </h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Super stuff!</b>
<div class="overflow">
<p>I wanted a simple yet trendy book cover design to attract more and more readers. I managed something myself through certain free applications, 
but ended up making a mess of my book cover lol. Thank God I opted for these Best Book Writers guys and they are friendly and super professional in their work. 
</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc2">
<h6>Neda Salim</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Marketing professionals</b>
<div class="overflow">
<p>Thanks a lot guys! You guys just did something super special for me. I am so happy to hire you guys as my marketing strategist. Give some recognition to Beckham he surely should be compensated more :)</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Sarah Edwards</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Research gurus</b>
<div class="overflow">
<p>The topic of my book was literally very difficult and people said no to me because of my core ground-breaking medicinal research. The David was super professional and Best Book Writers is certainly a professional Book writing brand. Thanks Guys!!!  
</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Silvia Peter </h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Publishing done in a professional manner</b>
<div class="overflow">
<p>I was worried about publishing of the book because I was done with writing the book, design of the book cover, and a bit of marketing.
However, I want to change the publisher and wanted a formidable publisher to publish my book. Best Book Writers people helped me out in this domain and they are professionals.   
</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Irene Samuels</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Book writing completed within my deadline</b>
<div class="overflow">
<p>The guy Alex was a professional and super honest with me when it comes to delivering the complete book in 15 days. I committed with my husband that we
should outsource this work and I am glad that these guys helped me out in a professional manner.    
</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Lene Steve</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>100% satisfied</b>
<div class="overflow">
<p> I just provided the basic outline to the writers at Best Book Writers and they produced a superb draft. The editing department along with quality assurance was up to date with their work.
I have realized that the dollars spent on these guys was a viable investment.     
</p>
</div>
</div>
</div>
</div>

<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Melina Sim</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Smooth and entertaining process</b>
<div class="overflow">
<p>The Book writing process looks cumbersome, but it was entertaining and professional to the core. I loved the engagement that you guys create with the customers, and the best part is that we can contact you whenever we want.     
</p>
</div>
</div>
</div>
</div>


<div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4 col-xxl-4">
<div class="card test-card">
<div class="desc desc3">
<h6>Steven smith</h6>
<span class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</span>
<b>Super error free work!</b>
<div class="overflow">
<p>I was short on money and I had a very tight budget. My loan was still on pending, but you guys helped
me out and provided an installment plan. I still cannot imagine that you I signed up in just 200 bucks. I am ready to opt or an audio book too once my loan is approved.      
</p>
</div>
</div>
</div>
</div>



</div>
</div>
</section>