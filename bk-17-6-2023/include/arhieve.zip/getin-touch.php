<section class="contact-section container">
<div class="row">
<div class="col-xl-10 offset-xl-1">
<h2 class="section__title">Get Published This Year!<span>Get In Touch Today</span></h2>
</div>
</div>
<div class="pt-80" id="contact-section">
<div class="row">
<div class="col-lg-7 col-sm-12 col-lg-7 col-xl-7 wow fadeInLeft animated" data-wow-duration="3s" style="visibility: visible; animation-duration: 3s; animation-name: fadeInLeft;">
<div class="frm_area_btm">
<form data-noinfo="true" data-customcallback="querycallback" class="CrudForm cmxform" id="signup-form" method="POST" action="include/sendmail">
                        <input type="hidden" required name="page_url" value="https://bestbookwriter.com" />  
          <div class="alert alert-danger error" style="display: none;"></div>
<h4>Tell Us About Your Project</h4>
<input type="text" placeholder="Your Name" name="name" required="">
<input type="email" placeholder="Your Email" name="email" required="">
<input type="number" placeholder="Your Phone Number" name="number" required="">
<textarea name="msg" cols="30" rows="10" placeholder="Enter Message"></textarea>
<div class="form-check">
<input type="checkbox" class="form-check-input" id="exampleCheck1">
<label class="form-check-label" for="exampleCheck1">Send me your NDA</label>
</div>
<button type="submit">LET’S TALK</button>
</form>
</div>
</div>
<div class="col-lg-5 col-sm-12 col-lg-5 col-xl-5 wow fadeInRight animated" data-wow-duration="3s" style="visibility: visible; animation-duration: 3s; animation-name: fadeInRight;">
<div class="contact-flow">
<h2 class="contact-flow__title">
<span class="in-violet-450 font-700">What to</span>
expect now?
</h2>
<ol class="ordered-list pt-0">
<li class="contact-flow__list-item ordered-list__item">
We know it can get a little puzzling where to go from here, but you needn’t fret. Trust the process. Our team of experts will get in touch within the next 24 hours to delve into more details with regards to your future best-seller.



</li>
<li class="contact-flow__list-item ordered-list__item">
After ascertaining what you have in mind, we will move to the next step which will entail conferring with our writers. They will discuss what the best tonality for your story would be.
</li>
<li class="contact-flow__list-item ordered-list__item">
Once we have the tonality you are looking for down and locked our seasoned writers will draw up an outline which will then be sent over for your approval.
</li>
<li class="contact-flow__list-item ordered-list__item">
After we get your approval one of our representatives will get in touch with you again to ensure everything is up to your mark one last time.
</li>
<li class="contact-flow__list-item ordered-list__item">
Following that your journey to becoming a best-selling author begins.
</li>
</ol>
</div>
</div>
</div>
</div>
</section>