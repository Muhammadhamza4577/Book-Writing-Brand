<div class="blog-form">
				<div class="newsletter_form">
<h5 class="modal-title" id="exampleModalLabel">Avail <span>50% Discount</span> on All Services</h5>
<p>REDEEM YOUR COUPON: <strong> Best Book Writers50</strong></p>

          <form data-noinfo="true" data-customcallback="querycallback" class="CrudForm cmxform" id="package_form" method="POST" action="include/sendmail">
                        <input type="hidden" required name="page_url" value="https://bestbookwriter.com" />  
          <div class="alert alert-danger error" style="display: none;"></div>
<div class="row mb-6">
<div class="">
<div class="input-div">
<i class="fa fa-user"></i>
<input type="text" placeholder="Enter Your Name" name="name" required="">
</div>
</div>
<div class="">
<div class="input-div">
<i class="fa fa-envelope"></i>
<input type="email" placeholder="Enter Your Email" name="email" required="">
</div>
</div>
</div>
<div class="input-div">
<i class="fa fa-phone"></i>
<input type="number" placeholder="Phone Number" name="phone" required="">
</div>
<div class="input-div">
<select name="services" required="">
<option value="ghostwriting">Ghostwriting</option>
<option value="bookediting">Book Editing and Proofreading</option>
<option value="bookcoverdesign">Book Cover Design</option>
<option value="e-bookcoverdesign">e-book Cover Design</option>
<option value="bookpublished">Book Publishing</option>
<option value="bookmarketing">Book Marketing</option>
 </select>
</div>
<button type="submit" class="btn hvr-grow tc-image-effect-shine">Submit</button>
</form>
</div>
</div>