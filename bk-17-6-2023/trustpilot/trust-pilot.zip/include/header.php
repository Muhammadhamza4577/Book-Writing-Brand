<header class="clearHeader">
   <div class="container">
      <div class="row">

         <div class="col-md-2">
               <div class="logo">
                  <img src="images/logo.png">
               </div>
         </div>

         <div class="col-md-6">
            <div class="input-fld">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-search" aria-hidden="true"></i></span>
                    </div>
                     <input type="text" class="form-control" placeholder="Search for another company…" aria-label="Username" aria-describedby="basic-addon1">
                  </div>
               </div>
         </div>
            <div class="col-md-4">
               <div class="right-btns">
                  <ul>
                     <li><a href="javascript:void(0)">Categories</a> </li>
                     <li><a href="javascript:void(0)">Blog</a></li>
                     <li><a href="javascript:void(0)">Log in</a></li>
                     <li class="bussiness"><a href="javascript:void(0)">For businesses</a></li>
                  </ul>
               </div>
         </div>
      </div>
   </div>
</header>